<?php
/**
 * Plugin Name: SAIA Pricing Configurator
 * Plugin URI: https://www.saiasoftware.com
 * Description: Carga las paginas HTML existentes (index, configurador, comparacion) como shortcodes WordPress sin alterar su contenido.
 * Version: 2.0.2
 * Author: SAIA Software
 * Author URI: https://www.saiasoftware.com
 * License: GPL-2.0+
 * Requires at least: 5.0
 * Requires PHP: 7.2
 *
 * Estructura esperada del plugin:
 *
 *   saia-pricing-configurator/
 *   ├── saia-pricing-configurator.php   (este archivo)
 *   ├── index.html                      (copia del HTML original)
 *   ├── configurator.html               (copia del HTML original)
 *   ├── comparison.html                 (copia del HTML original)
 *   └── assets/
 *       ├── css/styles.css
 *       ├── js/   (versiones con getDataUrl)
 *       └── data/ (JSON de configuracion)
 *
 * Shortcodes:
 *   [saia_planes]       → index.html
 *   [saia_configurator] → configurator.html
 *   [saia_comparison]   → comparison.html
 */

if (!defined('ABSPATH')) {
    exit;
}

define('SAIA_DIR', plugin_dir_path(__FILE__));
define('SAIA_URL', plugin_dir_url(__FILE__));
define('SAIA_VER', '2.0.2');

final class SAIA_Loader {

    /**
     * Mapa de shortcodes → archivos HTML y scripts necesarios.
     * El orden de scripts respeta las dependencias de cada pagina.
     */
    private static $pages = [
        'saia_planes' => [
            'file'    => 'index.html',
            'scripts' => [
                'general-config',
                'config',
                'plans-config',
                'plans-renderer',
                'proposal-benefits',
                'faq',
                'main',
                'iframe-resizer',
            ],
        ],
        'saia_configurator' => [
            'file'    => 'configurator.html',
            'scripts' => [
                'general-config',
                'config',
                'calculator',
                'configurator',
                'proposal-benefits',
                'tooltips',
                'faq',
                'main',
                'iframe-resizer',
            ],
        ],
        'saia_comparison' => [
            'file'    => 'comparison.html',
            'scripts' => [
                'general-config',
                'config',
                'comparison-config',
                'comparison-renderer',
                'faq',
                'iframe-resizer',
            ],
        ],
    ];

    /** @var string|null Tag del shortcode detectado en la pagina actual */
    private $detected = null;

    public function __construct() {
        add_action('init', [$this, 'register_shortcodes']);
        add_action('wp', [$this, 'early_detect']);
    }

    /* ------------------------------------------------------------------ */
    /*  Registro de shortcodes                                            */
    /* ------------------------------------------------------------------ */

    public function register_shortcodes() {
        foreach (array_keys(self::$pages) as $tag) {
            add_shortcode($tag, [$this, 'render']);
        }
    }

    /* ------------------------------------------------------------------ */
    /*  Deteccion temprana (hook wp) para CSS en <head> y desactivar       */
    /*  wpautop/wptexturize que alterarian el HTML inyectado.             */
    /* ------------------------------------------------------------------ */

    public function early_detect() {
        if (is_admin()) {
            return;
        }

        global $post;
        if (!is_a($post, 'WP_Post')) {
            return;
        }

        foreach (array_keys(self::$pages) as $tag) {
            if (has_shortcode($post->post_content, $tag)) {
                $this->detected = $tag;

                // Evitar que WordPress modifique el HTML del shortcode
                remove_filter('the_content', 'wpautop');
                remove_filter('the_content', 'wptexturize');

                // Encolar CSS antes de wp_head
                add_action('wp_enqueue_scripts', [$this, 'enqueue_styles']);
                break;
            }
        }
    }

    /* ------------------------------------------------------------------ */
    /*  Enqueue de CSS                                                    */
    /*                                                                    */
    /*  Todo el CSS del plugin se carga dentro de un @layer(saia).        */
    /*  Los estilos en un layer tienen MENOR prioridad que los estilos    */
    /*  sin layer (los del tema WP), asi Bootstrap no afecta              */
    /*  header/footer del tema.                                           */
    /*                                                                    */
    /*  Dentro de #app-root se re-aplican los estilos necesarios          */
    /*  como reglas sin layer (maxima prioridad).                         */
    /* ------------------------------------------------------------------ */

    public function enqueue_styles() {
        $css_url = esc_url(SAIA_URL . 'assets/css/styles.css?ver=' . SAIA_VER);

        wp_register_style('saia-all', false);
        wp_enqueue_style('saia-all');
        wp_add_inline_style('saia-all', implode("\n", [
            // --- Imports dentro del layer (menor prioridad que el tema) ---
            '@import url("https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap") layer(saia);',
            '@import url("https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css") layer(saia);',
            '@import url("https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css") layer(saia);',
            '@import url("' . $css_url . '") layer(saia);',
            '',
            '/* --- Re-aplicar estilos esenciales dentro de #app-root (sin layer = maxima prioridad) --- */',
            '#app-root {',
            '  font-family: "Outfit", "Inter", system-ui, -apple-system, sans-serif;',
            '  font-size: 1rem;',
            '  font-weight: 400;',
            '  line-height: 1.6;',
            '  color: #212529;',
            '  -webkit-text-size-adjust: 100%;',
            '}',
            '#app-root *, #app-root *::before, #app-root *::after {',
            '  box-sizing: border-box;',
            '}',
            '#app-root a { color: var(--primary, #0d6efd); text-decoration: underline; }',
            '#app-root a:hover { color: var(--primary-hover, #0a58ca); }',
            '#app-root img, #app-root svg { vertical-align: middle; max-width: 100%; height: auto; }',
            '#app-root h1, #app-root h2, #app-root h3, #app-root h4, #app-root h5, #app-root h6 {',
            '  margin-top: 0; margin-bottom: 0.5rem; font-weight: 500; line-height: 1.2;',
            '}',
            '#app-root p { margin-top: 0; margin-bottom: 1rem; }',
            '#app-root ul, #app-root ol { padding-left: 2rem; }',
        ]));
    }

    /* ------------------------------------------------------------------ */
    /*  Enqueue de JS (footer) — llamado desde el shortcode               */
    /* ------------------------------------------------------------------ */

    private function enqueue_scripts($tag) {
        $scripts = self::$pages[$tag]['scripts'];

        $prev = null;
        foreach ($scripts as $handle) {
            $deps = $prev !== null ? ['saia-' . $prev] : [];
            wp_enqueue_script(
                'saia-' . $handle,
                SAIA_URL . 'assets/js/' . $handle . '.js',
                $deps,
                SAIA_VER,
                true
            );
            $prev = $handle;
        }

        // Pasar URL del plugin al JS para resolver rutas de fetch()
        wp_localize_script('saia-config', 'saiaData', [
            'pluginUrl' => SAIA_URL,
            'dataUrl'   => SAIA_URL . 'assets/data/',
        ]);
    }

    /* ------------------------------------------------------------------ */
    /*  Render del shortcode                                              */
    /* ------------------------------------------------------------------ */

    public function render($atts, $content, $tag) {
        if (!isset(self::$pages[$tag])) {
            return '';
        }

        $file = SAIA_DIR . self::$pages[$tag]['file'];

        if (!file_exists($file)) {
            return '<!-- SAIA: archivo ' . esc_html(self::$pages[$tag]['file']) . ' no encontrado -->';
        }

        // Encolar JS de esta pagina (footer — aun esta a tiempo)
        $this->enqueue_scripts($tag);

        // Fallback: si CSS no se detecto en early_detect (page builders)
        if ($this->detected === null) {
            $this->enqueue_styles();
        }

        $html = file_get_contents($file);
        $body = $this->extract_body($html);

        return '<div id="app-root">' . $body . '</div>';
    }

    /* ------------------------------------------------------------------ */
    /*  Extraccion del contenido del body                                 */
    /*                                                                    */
    /*  Elimina DOCTYPE, <html>, <head>, <body>, <script>, <link>         */
    /*  sin alterar el contenido interno del body.                        */
    /* ------------------------------------------------------------------ */

    private function extract_body($html) {
        // DOCTYPE
        $html = preg_replace('/<!DOCTYPE[^>]*>/i', '', $html);
        // <html> y </html>
        $html = preg_replace('/<\/?html[^>]*>/i', '', $html);
        // <head>...</head> completo
        $html = preg_replace('/<head\b[^>]*>.*?<\/head>/is', '', $html);
        // <body> y </body> (conserva contenido interno)
        $html = preg_replace('/<\/?body[^>]*>/i', '', $html);
        // <script>...</script> (JS se carga via wp_enqueue_script)
        $html = preg_replace('/<script\b[^>]*>.*?<\/script>/is', '', $html);
        // <link ...> (CSS se carga via wp_enqueue_style)
        $html = preg_replace('/<link\b[^>]*\/?>/i', '', $html);

        return trim($html);
    }
}

new SAIA_Loader();
