<?php
/**
 * Template de tabla de comparación
 *
 * @package SAIA_Configurator
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="saia-comparison-wrapper" id="saia-comparison-<?php echo esc_attr(uniqid()); ?>">

    <!-- Main Content -->
    <div class="container py-5">
        <div class="text-center mb-5">
            <h1 class="fw-bold mb-3"><?php esc_html_e('Comparativo Detallado', 'saia-configurator'); ?></h1>
            <p class="text-muted lead"><?php esc_html_e('Analice funcionalidad por funcionalidad y elija el plan perfecto.', 'saia-configurator'); ?></p>
            <div class="mt-4">
                <a href="https://www.saiasoftware.com/planes/" class="btn-demo rounded-pill" style="display: inline-block; width: auto;">
                    <i class="fa-solid fa-arrow-left me-2"></i><?php esc_html_e('Volver a Precios', 'saia-configurator'); ?>
                </a>
            </div>
            <div class="mt-4 mb-4">
                <a href="https://www.saiasoftware.com/#demo" class="btn-demo-secondary rounded-pill px-5 py-3 fw-bold">
                    <?php esc_html_e('Solicitar Demo', 'saia-configurator'); ?>
                </a>
            </div>
        </div>

        <!-- Comparison Table Container -->
        <div id="comparison-container" class="mb-5 shadow-sm rounded-4 overflow-hidden border">
            <!-- Table injected by comparison-renderer.js -->
        </div>

        <!-- CTA Feature -->
        <div class="bg-light p-5 rounded-4 text-center mt-5">
            <h3 class="fw-bold mb-3"><?php esc_html_e('¿Necesita asistencia personalizada?', 'saia-configurator'); ?></h3>
            <p class="text-muted mb-4"><?php esc_html_e('Nuestros expertos pueden ayudarle a definir la arquitectura ideal para su empresa.', 'saia-configurator'); ?></p>
            <a href="https://www.saiasoftware.com/configurador/" class="btn-primary-custom rounded-pill px-4 py-2">
                <?php esc_html_e('Configurar a Medida', 'saia-configurator'); ?> <i class="fa-solid fa-arrow-right ms-2"></i>
            </a>
        </div>
    </div>

    <!-- FAQ Section -->
    <section id="faq" class="pricing-faq">
        <div class="container">
            <h2 class="faq-title"><?php esc_html_e('Preguntas Frecuentes', 'saia-configurator'); ?></h2>
            <div id="faq-container" class="faq-accordion">
                <!-- FAQ items will be rendered here by JavaScript -->
            </div>
            <div class="faq-cta">
                <p><?php esc_html_e('¿No encuentras lo que buscas?', 'saia-configurator'); ?>
                    <a href="https://www.saiasoftware.com/registro/"><?php esc_html_e('Contáctanos', 'saia-configurator'); ?></a>
                </p>
            </div>
        </div>
    </section>
</div>
