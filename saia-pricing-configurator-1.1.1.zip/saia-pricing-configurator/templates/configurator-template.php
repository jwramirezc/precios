<?php
/**
 * Template del configurador personalizado
 *
 * @package SAIA_Configurator
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="saia-configurator-wrapper" id="saia-configurator-<?php echo esc_attr(uniqid()); ?>">

    <!-- Botón volver -->
    <div class="container py-5">
        <div class="text-center mb-4">
            <?php
            $all_pages_nav = get_pages(array('post_status' => 'publish'));
            $planes_url = '';
            foreach ($all_pages_nav as $page) {
                if (has_shortcode($page->post_content, 'saia_plans')) {
                    $planes_url = get_permalink($page->ID);
                    break;
                }
            }
            if (empty($planes_url)) {
                $planes_url = 'javascript:history.back()';
            }
            ?>
            <a href="<?php echo esc_url($planes_url); ?>" class="btn-demo rounded-pill">
                <i class="fa-solid fa-arrow-left me-2"></i><?php esc_html_e('Volver a Planes', 'saia-configurator'); ?>
            </a>
        </div>
    </div>

    <!-- Main Header -->
    <div class="container py-4">
        <div class="text-center mb-5">
            <h2 class="display-6 fw-bold mb-3" style="color: var(--primary);">
                <?php esc_html_e('Configura tu plataforma SAIA en menos de 30 segundos y recibe una cotización exacta para tu organización.', 'saia-configurator'); ?>
            </h2>

            <p class="lead text-muted">
                <?php esc_html_e('Selecciona los módulos, usuarios y recursos que necesitas, y obtén una propuesta personalizada sin compromiso.', 'saia-configurator'); ?>
            </p>
            <p class="small text-muted mt-3 mb-0">
                <?php esc_html_e('Tu configuración se basa en una plataforma segura, certificada y respaldada en tecnología AWS con cumplimiento normativo ISO y respaldo automático diario.', 'saia-configurator'); ?>
            </p>
        </div>
    </div>

    <div class="container" id="configurator-container">
        <!-- Main Content: Modules -->
        <main>
            <div id="modules-container" class="modules-grid">
                <!-- Modules will be injected here by JS -->
            </div>
        </main>

        <!-- Sidebar: Configuration & Price -->
        <aside>
            <div class="configurator-panel">
                <h2 class="section-title"><?php esc_html_e('Configuración', 'saia-configurator'); ?></h2>

                <!-- SaaS Info Card -->
                <div class="alert alert-light border shadow-sm mb-4" role="alert">
                    <ul class="list-unstyled mb-0 small">
                        <li class="mb-2">
                            <i class="fa-solid fa-check text-success me-2"></i>
                            <?php esc_html_e('Modelo SaaS 100% en la nube', 'saia-configurator'); ?>
                        </li>
                        <li class="mb-2">
                            <i class="fa-solid fa-check text-success me-2"></i>
                            <?php esc_html_e('Acceso 24/7 desde cualquier lugar', 'saia-configurator'); ?>
                        </li>
                        <li class="mb-2">
                            <i class="fa-solid fa-check text-success me-2"></i>
                            <?php esc_html_e('Actualizaciones automáticas incluidas', 'saia-configurator'); ?>
                        </li>
                        <li class="mb-2">
                            <i class="fa-solid fa-check text-success me-2"></i>
                            <?php esc_html_e('Respaldo y protección de la información', 'saia-configurator'); ?>
                        </li>
                        <li class="mb-2">
                            <i class="fa-solid fa-check text-success me-2"></i>
                            <?php esc_html_e('Escalable según usuarios y módulos', 'saia-configurator'); ?>
                        </li>
                        <li>
                            <i class="fa-solid fa-check text-success me-2"></i>
                            <?php esc_html_e('Soporte técnico especializado', 'saia-configurator'); ?>
                        </li>
                    </ul>
                </div>

                <!-- Billing Frequency (SaaS Only) -->
                <div class="control-group" id="billing-frequency-group">
                    <label><?php esc_html_e('Frecuencia de Pago', 'saia-configurator'); ?></label>
                    <div class="license-options">
                        <div class="radio-card active" id="btn-monthly" onclick="setBilling('monthly')">
                            <?php esc_html_e('Mensual', 'saia-configurator'); ?>
                        </div>
                        <div class="radio-card" id="btn-annual" onclick="setBilling('annual')">
                            <?php esc_html_e('Anual', 'saia-configurator'); ?> (<span id="annual-discount-label">-15%</span>)
                        </div>
                    </div>
                </div>

                <!-- Users Slider -->
                <div class="control-group">
                    <label>
                        <?php esc_html_e('Número de Usuarios:', 'saia-configurator'); ?> <span id="user-count-display">10</span>
                        <i class="fa-solid fa-circle-info text-primary ms-1" style="cursor: pointer;"
                            data-tooltip-id="numero_usuarios" aria-label="<?php esc_attr_e('Ayuda sobre número de usuarios', 'saia-configurator'); ?>"></i>
                    </label>
                    <div class="range-wrap">
                        <input type="range" id="users-input" min="5" max="500" value="10" step="5"
                            oninput="updateUsers(this.value)">
                    </div>
                </div>

                <!-- Storage Slider -->
                <div class="control-group">
                    <label>
                        <?php esc_html_e('Almacenamiento (GB):', 'saia-configurator'); ?> <span id="storage-count-display">100</span>
                        <i class="fa-solid fa-circle-info text-primary ms-1" style="cursor: pointer;"
                            data-tooltip-id="almacenamiento_gb" aria-label="<?php esc_attr_e('Ayuda sobre almacenamiento', 'saia-configurator'); ?>"></i>
                    </label>
                    <div class="range-wrap">
                        <input type="range" id="storage-input" min="10" max="1000" value="100" step="10"
                            oninput="updateStorage(this.value)">
                    </div>
                    <div class="d-flex justify-content-between mt-1 text-muted" style="font-size: 0.75rem;">
                        <span><?php esc_html_e('Incluye 100 GB sin costo', 'saia-configurator'); ?></span>
                        <span><?php esc_html_e('Descuentos por volumen', 'saia-configurator'); ?></span>
                    </div>
                </div>

                <!-- Currency Selector -->
                <div class="control-group">
                    <label><?php esc_html_e('Moneda', 'saia-configurator'); ?></label>
                    <div class="license-options">
                        <div class="radio-card active" id="btn-cop" onclick="setCurrency('COP')">
                            COP (<?php esc_html_e('Pesos', 'saia-configurator'); ?>)
                        </div>
                        <div class="radio-card" id="btn-usd" onclick="setCurrency('USD')">
                            USD (<?php esc_html_e('Dólares', 'saia-configurator'); ?>)
                        </div>
                    </div>
                </div>

                <!-- Custom Services Summary -->
                <div id="custom-services-summary" class="custom-services-summary" style="display: none;">
                    <h3 class="section-title small mb-2"><?php esc_html_e('Servicio Adicional', 'saia-configurator'); ?></h3>
                    <div id="custom-services-list"></div>
                </div>

                <!-- Total -->
                <div class="price-display">
                    <span class="price-label" id="price-label"><?php esc_html_e('Precio Estimado (Mensual)', 'saia-configurator'); ?></span>
                    <div id="original-price-container" style="display: none;" class="mb-2">
                        <span class="text-muted text-decoration-line-through small" id="original-price">$0</span>
                    </div>
                    <span class="total-price" id="total-price">$0</span>
                </div>

                <a href="#" class="btn-cta" id="contact-cta" data-link="personalizedQuote">
                    <?php esc_html_e('Obtener Cotización Formal Exacta', 'saia-configurator'); ?><br>
                    <?php esc_html_e('en 24 Horas', 'saia-configurator'); ?>
                </a>

                <a href="#" data-link="requestDemo" class="btn-demo rounded-pill mt-3" style="width: 100%;">
                    <?php esc_html_e('Solicitar Demo', 'saia-configurator'); ?>
                </a>

                <!-- What's Included Section -->
                <div id="proposal-benefits-container-configurator">
                    <!-- Benefits will be rendered here by proposal-benefits.js -->
                </div>
            </div>
        </aside>
    </div>

    <!-- FAQ Section -->
    <section id="faq" class="pricing-faq">
        <div class="container">
            <h2 class="faq-title"><?php esc_html_e('Preguntas Frecuentes', 'saia-configurator'); ?></h2>
            <div id="faq-container" class="faq-accordion">
                <!-- FAQ items will be rendered here by JavaScript -->
            </div>

            <!-- Final CTA Section -->
            <div class="text-center py-4 my-4">
                <p class="lead mb-3" style="color: var(--dark);">
                    <?php esc_html_e('¿Listo para optimizar tu operación? Configura tu plan y recibe tu propuesta en minutos.', 'saia-configurator'); ?>
                </p>
                <?php
                $planes_url_faq = '';
                foreach ($all_pages_nav as $page) {
                    if (has_shortcode($page->post_content, 'saia_plans')) {
                        $planes_url_faq = get_permalink($page->ID);
                        break;
                    }
                }
                if (empty($planes_url_faq)) {
                    $planes_url_faq = 'javascript:history.back()';
                }
                ?>
                <a href="<?php echo esc_url($planes_url_faq); ?>" class="btn-outline-primary-custom rounded-pill px-4 py-2">
                    <?php esc_html_e('Ver Planes Predefinidos', 'saia-configurator'); ?>
                </a>
            </div>

            <div class="faq-cta">
                <p><?php esc_html_e('¿No encuentras lo que buscas?', 'saia-configurator'); ?>
                    <a href="#" data-link="contactUs"><?php esc_html_e('Contáctanos', 'saia-configurator'); ?></a>
                </p>
            </div>
        </div>
    </section>
</div>
