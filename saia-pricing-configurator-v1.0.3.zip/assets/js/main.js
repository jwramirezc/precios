/**
 * Shared Logic for Pricing System
 * Handles common interactions like navigation or mobile menus
 */

// Example: Scroll to Configurator if on same page (used by 'A MEDIDA' button if refactored)
// Currently 'configurator.html' handles its own init.

console.log('Main JS loaded');
