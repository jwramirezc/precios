<?php
/**
 * Template de tabla de comparación
 *
 * @package SAIA_Configurator
 */

if (!defined('ABSPATH')) {
    exit;
}

// Buscar páginas de planes y configurador
$all_pages = get_pages(array('post_status' => 'publish'));
$planes_url = '';
$configurador_url = '';
foreach ($all_pages as $page) {
    if (has_shortcode($page->post_content, 'saia_plans') && empty($planes_url)) {
        $planes_url = get_permalink($page->ID);
    }
    if (has_shortcode($page->post_content, 'saia_configurator') && empty($configurador_url)) {
        $configurador_url = get_permalink($page->ID);
    }
}
// Fallback: usar history.back() si no se encuentran las páginas
if (empty($planes_url)) {
    $planes_url = 'javascript:history.back()';
}
if (empty($configurador_url)) {
    $configurador_url = 'javascript:history.back()';
}
?>

<div class="saia-comparison-wrapper" id="saia-comparison-<?php echo esc_attr(uniqid()); ?>">

    <!-- Main Content -->
    <div class="container py-5">
        <div class="text-center mb-5">
            <h1 class="fw-bold mb-3"><?php esc_html_e('Comparativo Detallado', 'saia-configurator'); ?></h1>
            <p class="text-muted lead"><?php esc_html_e('Analice funcionalidad por funcionalidad y elija el plan perfecto.', 'saia-configurator'); ?></p>
            <div class="mt-4">
                <a href="<?php echo esc_url($planes_url); ?>" class="btn-demo rounded-pill">
                    <i class="fa-solid fa-arrow-left me-2"></i><?php esc_html_e('Volver a Precios', 'saia-configurator'); ?>
                </a>
            </div>
            <div class="mt-4 mb-4">
                <a href="#" data-link="requestDemo" class="btn-demo-secondary rounded-pill px-5 py-3 fw-bold">
                    <?php esc_html_e('Solicitar Demo', 'saia-configurator'); ?>
                </a>
            </div>
        </div>

        <!-- Comparison Table Container -->
        <div id="comparison-container" class="mb-5 shadow-sm rounded-4 overflow-hidden border">
            <!-- Table injected by comparison-renderer.js -->
        </div>

        <!-- CTA Feature -->
        <div class="bg-light p-5 rounded-4 text-center mt-5">
            <h3 class="fw-bold mb-3"><?php esc_html_e('¿Necesita asistencia personalizada?', 'saia-configurator'); ?></h3>
            <p class="text-muted mb-4"><?php esc_html_e('Nuestros expertos pueden ayudarle a definir la arquitectura ideal para su empresa.', 'saia-configurator'); ?></p>
            <a href="<?php echo esc_url($configurador_url); ?>" class="btn-primary-custom rounded-pill px-4 py-2">
                <?php esc_html_e('Configurar a Medida', 'saia-configurator'); ?> <i class="fa-solid fa-arrow-right ms-2"></i>
            </a>
        </div>
    </div>

    <!-- FAQ Section -->
    <section id="faq" class="pricing-faq">
        <div class="container">
            <h2 class="faq-title"><?php esc_html_e('Preguntas Frecuentes', 'saia-configurator'); ?></h2>
            <div id="faq-container" class="faq-accordion">
                <!-- FAQ items will be rendered here by JavaScript -->
            </div>
            <div class="faq-cta">
                <p><?php esc_html_e('¿No encuentras lo que buscas?', 'saia-configurator'); ?>
                    <a href="#" data-link="contactUs"><?php esc_html_e('Contáctanos', 'saia-configurator'); ?></a>
                </p>
            </div>
        </div>
    </section>
</div>
